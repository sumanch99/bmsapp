import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-myfd',
  templateUrl: './customer-myfd.component.html',
  styleUrls: ['./customer-myfd.component.css']
})
export class CustomerMyfdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
