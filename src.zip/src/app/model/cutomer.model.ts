export class Customer
{
   
	userId:string='';
	password:string='';
	firstName:string='';
	lastName:string='';
	gender:string='';
	address:string='';
	town:string='';
	district:string='';
	state:string='';
	pinCode:number=0;
	dateOfBirth:Date=new Date();
	emailId:string='';
	phoneNumber:string ='';
	adhaarNo:string='';
    constructor()
    {
        
    }
}