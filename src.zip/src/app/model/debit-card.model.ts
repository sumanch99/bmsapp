export class DebitCard{
    cardNo:number=0;
    pin:number | undefined;
    cvvNo:number | undefined;
    accountNo:number | undefined;
    approved:boolean | undefined;

}