export class FixedDeposit{
    amount:number=0;
	tenure:number=0;
	account_number:number=0;
}