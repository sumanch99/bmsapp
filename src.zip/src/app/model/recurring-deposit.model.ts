export class RecurringDeposit {
    monthlyAmount: number = 0;
    tenure: number = 0;
    accountNumber: number = 0;
}