export class JSONResponse{
    data:any;
    message:any;
    status:any;
}