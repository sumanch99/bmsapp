import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-deposit',
  templateUrl: './customer-deposit.component.html',
  styleUrls: ['./customer-deposit.component.css']
})
export class CustomerDepositComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
