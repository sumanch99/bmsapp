import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-check-transactions',
  templateUrl: './customer-check-transactions.component.html',
  styleUrls: ['./customer-check-transactions.component.css']
})
export class CustomerCheckTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
