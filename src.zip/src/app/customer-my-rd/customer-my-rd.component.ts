import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-my-rd',
  templateUrl: './customer-my-rd.component.html',
  styleUrls: ['./customer-my-rd.component.css']
})
export class CustomerMyRdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
