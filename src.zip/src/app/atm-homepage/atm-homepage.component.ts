import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atm-homepage',
  templateUrl: './atm-homepage.component.html',
  styleUrls: ['./atm-homepage.component.css']
})
export class AtmHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
