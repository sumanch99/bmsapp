import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-setup',
  templateUrl: './admin-setup.component.html',
  styleUrls: ['./admin-setup.component.css']
})
export class AdminSetupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
