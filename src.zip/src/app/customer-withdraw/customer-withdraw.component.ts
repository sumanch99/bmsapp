import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-withdraw',
  templateUrl: './customer-withdraw.component.html',
  styleUrls: ['./customer-withdraw.component.css']
})
export class CustomerWithdrawComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
